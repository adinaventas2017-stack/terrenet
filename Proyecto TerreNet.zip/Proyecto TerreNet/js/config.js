// ⚠️ CAMBIAR estoooo por los datos reales de tu proyecto
// Supabase -> Project Settings -> API

export const SUPABASE_URL = "https://lmwspcycesangbmcfjoj.supabase.co"; 
export const SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imxtd3NwY3ljZXNhbmdibWNmam9qIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjQ0NDU1NzAsImV4cCI6MjA4MDAyMTU3MH0.vUK_GgIQyKjlf1-yOWbT1t-1u6Td4E0XrakIkNJzRPw";
export const SUPABASE_STORAGE_BUCKET = "terrenos";
